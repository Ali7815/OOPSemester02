﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ocean_Navigation.BL;

namespace Ocean_Navigation
{
    class Program
    {
        static List<Angle> Ships = new List<Angle>();
        static void Main(string[] args)
        {
            while (true)
            {
                string op = menu();
                if(op=="1")
                {
                    Angle A = Add_ship();
                    Ships.Add(A);
                }
                else if(op=="2")
                {
                    disply_ship();
                }
                else if (op == "3")
                {

                }
                else if (op == "4")
                {
                    replace_ship();
                }
                else if (op == "5")
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Wrong Input.....");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
        }
        static string menu()
        {
            Console.WriteLine("[1]- Add Ship");
            Console.WriteLine("[2]- View Ship Position");
            Console.WriteLine("[3]- View Ship Serial Number");
            Console.WriteLine("[4]- Change Ship Position");
            Console.WriteLine("[5]- Exit");
            Console.Write("Your Option....");
            string o = Console.ReadLine();
            return o;
        }
        static Angle Add_ship()
        {
            Console.Write("Enter Ship Name : ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Ship Longitude....");
            Console.Write("Enter Longitude Degree : ");
            int LongiDeg = int.Parse(Console.ReadLine());
            Console.Write("Enter Longitude Minutes : ");
            float LongiMin = float.Parse(Console.ReadLine());
            Console.Write("Enter Longitude Direction : ");
            char LongiDir = char.Parse(Console.ReadLine());
            Console.WriteLine("Enter Ship Latitude....");
            Console.Write("Enter Latitude Degree : ");
            int LatiDeg = int.Parse(Console.ReadLine());
            Console.Write("Enter Latitude Minutes : ");
            float LatiMin = float.Parse(Console.ReadLine());
            Console.Write("Enter Latitude Direction : ");
            char LatiDir = char.Parse(Console.ReadLine());
            Angle A = new Angle(name,LongiDeg, LongiMin, LongiDir, LatiDeg, LatiMin, LatiDir);
            Console.Clear();
            return A;

        }
        static void Add_Ship2()
        {
            Console.WriteLine("Enter Ship Latitude....");
            Console.Write("Enter Latitude Degree : ");
            int LatiDeg = int.Parse(Console.ReadLine());
            Console.Write("Enter Latitude Minutes : ");
            float LatiMin = float.Parse(Console.ReadLine());
            Console.Write("Enter Latitude Direction : ");
            char LatiDir = char.Parse(Console.ReadLine());
           
        }
        static void disply_ship()
        {
            Console.WriteLine("Enter Ship Name : ");
            string s = Console.ReadLine();
            bool flag = false;
            for (int i = 0; i < Ships.Count; i++)
            {
                if(s==Ships[i].name)
                {
                    flag = true;
                    Console.WriteLine("Ship is at " + Ships[i].degree + "\u00b0" + Ships[i].minutes + "\u00b0" + Ships[i].direction + " and " + Ships[i].degree2 + "\u00b0" + Ships[i].minutes2 + "\u00b0" + Ships[i].direction2);
                }
            }
            if(flag==false)
            {
                Console.Write("No Such Ship Avilable");
            }
            Console.ReadKey();
            Console.Clear();
        }
        static void replace_ship()
        {
            bool flag = false;
            Console.WriteLine("Enter Ship Name : ");
            string s = Console.ReadLine();
            for (int i = 0; i < Ships.Count; i++)
            {
                if (s == Ships[i].name)
                {
                    flag = true;
                    Console.WriteLine("Enter Ship Longitude....");
                    Console.Write("Enter Longitude Degree : ");
                    int LongiDeg = int.Parse(Console.ReadLine());
                    Console.Write("Enter Longitude Minutes : ");
                    float LongiMin = float.Parse(Console.ReadLine());
                    Console.Write("Enter Longitude Direction : ");
                    char LongiDir = char.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Ship Latitude....");
                    Console.Write("Enter Latitude Degree : ");
                    int LatiDeg = int.Parse(Console.ReadLine());
                    Console.Write("Enter Latitude Minutes : ");
                    float LatiMin = float.Parse(Console.ReadLine());
                    Console.Write("Enter Latitude Direction : ");
                    char LatiDir = char.Parse(Console.ReadLine());
                    Angle A = new Angle(LongiDeg, LongiMin, LongiDir, LatiDeg, LatiMin, LatiDir);
                    Ships.Insert(i, A);
                    Console.Clear();
                    break;
                  
                }
            }
            if(flag==false)
            {
                Console.WriteLine("No Such Ships Avilable");
            }
        }
    }

}
