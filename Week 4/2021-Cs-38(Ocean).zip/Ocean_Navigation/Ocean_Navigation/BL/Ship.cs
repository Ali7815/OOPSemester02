﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean_Navigation.BL
{
    class Ship
    {
        public string name;
        public string location;
        public Ship(string name,string location)
        {
            this.name = name;
            this.location = location;
        }
    }
}
