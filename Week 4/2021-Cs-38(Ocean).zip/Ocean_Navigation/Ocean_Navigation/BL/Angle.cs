﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ocean_Navigation.BL
{
    class Angle
    {
        public int degree;
        public float minutes;
        public char direction;

        public int degree2;
        public float minutes2;
        public char direction2;
        public string name;
        public Angle(string name,int degree,float minutes,char direction,int degree2,float minutes2,char direction2)
        {
            this.name = name;
            this.degree = degree;
            this.minutes = minutes;
            this.direction = direction;

            this.degree2 = degree2;
            this.minutes2 = minutes2;
            this.direction2 = direction2;
        }
        public Angle(int degree, float minutes, char direction, int degree2, float minutes2, char direction2)
        {
            
            this.degree = degree;
            this.minutes = minutes;
            this.direction = direction;

            this.degree2 = degree2;
            this.minutes2 = minutes2;
            this.direction2 = direction2;
        }
        public void setvalue(int d,float m,char direct)
        {
            degree = d;
            m = minutes;
            direction = direct;
        }
        public void disply()
        {
            Console.WriteLine(degree + "\u00b0" + minutes + "\u00b0" + direction);
        }
    }
}
